"""VibeGrowth - frame-driven differential growth for open meshes and curves."""

import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty,
)

from . import sim as _sim

# Runtime state, keyed by Object.session_uid: {"sim": GrowthSim, "cache": {frame: GrowthSim}}
_RUNTIME = {}
_BUSY = False


# ---------------------------------------------------------------------------
# Seed reading
# ---------------------------------------------------------------------------

def _read_weights(ob_eval, me, name):
    """Per-vertex weights from a vertex group or a float point attribute."""
    if not name:
        return None
    attr = me.attributes.get(name)
    if attr is not None and attr.domain == 'POINT' and attr.data_type == 'FLOAT':
        vals = [0.0] * len(me.vertices)
        attr.data.foreach_get("value", vals)
        return vals
    vg = ob_eval.vertex_groups.get(name)
    if vg is None:
        return None
    idx = vg.index
    vals = [0.0] * len(me.vertices)
    for v in me.vertices:
        for g in v.groups:
            if g.group == idx:
                vals[v.index] = g.weight
                break
    return vals


def _read_seed(seed, depsgraph, group_names):
    ob = seed.evaluated_get(depsgraph)
    me = ob.to_mesh()
    try:
        data = {
            "cos": [v.co[:] for v in me.vertices],
            "edges": [tuple(e.vertices) for e in me.edges],
            "faces": [tuple(p.vertices) for p in me.polygons],
        }
        me.calc_loop_triangles()
        data["tris"] = [tuple(t.vertices) for t in me.loop_triangles]
        data["weights"] = {n: _read_weights(ob, me, n) for n in group_names if n}
    finally:
        ob.to_mesh_clear()
    return data


# ---------------------------------------------------------------------------
# Simulation driver
# ---------------------------------------------------------------------------

def _free_runtime(key):
    rt = _RUNTIME.pop(key, None)
    if rt:
        rt["sim"].free()
        for c in rt["cache"].values():
            c.free()


def _build_initial(ob, depsgraph):
    st = ob.vibegrowth
    data = _read_seed(st.seed_object, depsgraph, [st.mask_group])
    mask = data["weights"].get(st.mask_group) or [1.0] * len(data["cos"])
    return _sim.GrowthSim.from_geometry(
        data["cos"], data["edges"], data["faces"], mask,
        st.start_frame, st.random_seed, st.split_length, st.max_vertices,
    )


def simulate_to(ob, depsgraph, frame):
    st = ob.vibegrowth
    key = ob.session_uid
    rt = _RUNTIME.get(key)

    if rt is None or frame <= st.start_frame:
        _free_runtime(key)
        start = _build_initial(ob, depsgraph)
        rt = {"sim": start, "cache": {st.start_frame: start.copy()}}
        _RUNTIME[key] = rt

    sim = rt["sim"]
    if frame != sim.frame:
        # Jump to the best cached state at or before the target frame.
        cached = [f for f in rt["cache"] if f <= frame]
        best = max(cached) if cached else None
        if frame < sim.frame or (best is not None and best > sim.frame):
            if best is None:
                _free_runtime(key)
                return simulate_to(ob, depsgraph, frame)
            sim.free()
            sim = rt["cache"][best].copy()
            rt["sim"] = sim

    if sim.frame < frame:
        seed = st.seed_object
        weight_fn = None
        if st.weight_group:
            data = _read_seed(seed, depsgraph, [st.weight_group])
            w = data["weights"].get(st.weight_group)
            if w is not None:
                weight_fn = _sim.PointSampler(data["cos"], w, data["tris"], data["edges"])
        to_seed = seed.matrix_world.inverted() @ ob.matrix_world
        core = None
        if st.core_object is not None:
            core = (ob.matrix_world.inverted() @ st.core_object.matrix_world.translation)[:]
        while sim.frame < frame:
            sim.advance(st, sim.frame + 1, weight_fn, st.weight_space, to_seed, core)
            if st.use_cache:
                rt["cache"][sim.frame] = sim.copy()

    sim.write(ob.data)


def _growth_objects(scene):
    for ob in scene.objects:
        if ob.type == 'MESH' and ob.vibegrowth.enabled and ob.vibegrowth.seed_object is not None:
            if ob.vibegrowth.seed_object != ob:
                yield ob


@persistent
def _on_frame_change(scene, depsgraph=None):
    global _BUSY
    if _BUSY:
        return
    _BUSY = True
    try:
        depsgraph = depsgraph or bpy.context.evaluated_depsgraph_get()
        for ob in _growth_objects(scene):
            try:
                simulate_to(ob, depsgraph, scene.frame_current)
            except Exception as ex:  # keep playback alive
                print(f"VibeGrowth: {ob.name}: {ex!r}")
    finally:
        _BUSY = False


@persistent
def _on_load_pre(*_args):
    for key in list(_RUNTIME):
        _free_runtime(key)


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------

def _poll_mesh(_self, ob):
    return ob.type == 'MESH'


class VibeGrowthSettings(bpy.types.PropertyGroup):
    enabled: BoolProperty(name="Enabled", default=False)

    # Seed & time
    seed_object: PointerProperty(name="Seed Object", type=bpy.types.Object, poll=_poll_mesh,
                                 description="Starting geometry (open mesh or wire curve)")
    random_seed: IntProperty(name="Random Seed", default=0, min=0)
    start_frame: IntProperty(name="Start Frame", default=1)
    steps_per_frame: IntProperty(name="Steps per Frame", default=4, min=1, soft_max=20,
                                 description="Solver iterations per timeline frame")

    # Growth
    growth_rate: FloatProperty(name="Growth Speed", default=0.05, min=0.0, soft_max=1.0,
                               description="Relative edge growth per frame at weight 1")
    interior_growth: FloatProperty(name="Interior Growth", default=0.25, min=0.0, max=1.0,
                                   subtype='FACTOR',
                                   description="Growth of non-boundary vertices relative to the rim")
    mask_group: StringProperty(name="Initial Mask",
                               description="Static vertex group on the seed, read once at the start frame")
    weight_group: StringProperty(name="Growth Weight",
                                 description="Vertex group (or float attribute) on the seed, re-read every frame")
    weight_space: EnumProperty(
        name="Weight Space",
        items=[('REST', "Seed (Rest)", "Each vertex samples the seed at its original location"),
               ('WORLD', "Current Position", "Each vertex samples the seed at its current location")],
        default='REST')

    # Noise
    noise_influence: FloatProperty(name="Noise Influence", default=0.6, min=0.0, soft_max=2.0)
    noise_scale: FloatProperty(name="Noise Scale", default=2.0, min=0.0)
    noise_speed: FloatProperty(name="Noise Speed", default=0.05, description="Noise drift per frame")
    noise_space: EnumProperty(
        name="Noise Space",
        items=[('REST', "Seed (Rest)", "Noise is stuck to the material of the growth"),
               ('WORLD', "Current Position", "Noise is evaluated where the vertex is now")],
        default='REST')
    jitter: FloatProperty(name="Jitter", default=0.01, min=0.0, soft_max=1.0,
                          description="Random displacement that breaks symmetry")

    # Falloff
    core_object: PointerProperty(name="Core", type=bpy.types.Object,
                                 description="Center of the design (default: seed centroid)")
    core_radius: FloatProperty(name="Core Radius", default=0.0, min=0.0, unit='LENGTH')
    growth_decay: FloatProperty(name="Growth Decline", default=0.0, min=0.0, soft_max=20.0,
                                description="Exponential decline of growth beyond the core radius")

    # Repulsion
    repulsion_distance: FloatProperty(name="Repulsion Distance", default=0.1, min=0.0, unit='LENGTH')
    repulsion_strength: FloatProperty(name="Repulsion Strength", default=0.5, min=0.0, soft_max=2.0)
    repulsion_exponent: FloatProperty(name="Repulsion Falloff", default=3.0, min=0.0, soft_max=10.0,
                                      description="Higher = force rises more steeply as vertices get closer")
    collision_distance: FloatProperty(name="Collision Distance", default=0.03, min=0.0, unit='LENGTH',
                                      description="Hard minimum distance between vertices")

    # Remesh / solver
    split_length: FloatProperty(name="Split Length", default=0.1, min=0.0001, unit='LENGTH',
                                description="Edges longer than this are bisected and re-triangulated")
    max_vertices: IntProperty(name="Max Vertices", default=20000, min=10)
    spring_stiffness: FloatProperty(name="Edge Stiffness", default=1.0, min=0.0, max=1.0, subtype='FACTOR')
    spring_iterations: IntProperty(name="Edge Iterations", default=2, min=1, soft_max=10)
    smoothing: FloatProperty(name="Smoothing", default=0.5, min=0.0, max=1.0, subtype='FACTOR')
    planar: BoolProperty(name="Lock to Seed Plane", default=False)
    use_cache: BoolProperty(name="Cache Frames", default=True,
                            description="Keep frames in memory so scrubbing back is instant")


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class VIBEGROWTH_OT_create(bpy.types.Operator):
    bl_idname = "vibegrowth.create"
    bl_label = "Create Growth from Seed"
    bl_description = "Create a growth object driven by the active mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def execute(self, context):
        seed = context.object
        me = seed.data
        lengths = [(me.vertices[e.vertices[0]].co - me.vertices[e.vertices[1]].co).length for e in me.edges]
        avg = sum(lengths) / len(lengths) if lengths else 0.1

        ob = bpy.data.objects.new(seed.name + "_Growth", bpy.data.meshes.new(seed.name + "_Growth"))
        for coll in seed.users_collection:
            coll.objects.link(ob)
        ob.matrix_world = seed.matrix_world.copy()
        for slot in seed.material_slots:
            ob.data.materials.append(slot.material)

        st = ob.vibegrowth
        st.enabled = True
        st.seed_object = seed
        st.start_frame = context.scene.frame_start
        st.split_length = avg * 1.2
        st.repulsion_distance = avg * 1.2
        st.collision_distance = avg * 0.4
        if "growth" in seed.vertex_groups:
            st.weight_group = "growth"
        if "mask" in seed.vertex_groups:
            st.mask_group = "mask"

        seed.display_type = 'WIRE'
        seed.hide_render = True
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        context.scene.frame_set(context.scene.frame_current)
        return {'FINISHED'}


class VIBEGROWTH_OT_reset(bpy.types.Operator):
    bl_idname = "vibegrowth.reset"
    bl_label = "Reset Simulation"
    bl_description = "Clear the cache and re-simulate up to the current frame with the current settings"

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.vibegrowth.enabled

    def execute(self, context):
        ob = context.object
        _free_runtime(ob.session_uid)
        simulate_to(ob, context.evaluated_depsgraph_get(), context.scene.frame_current)
        return {'FINISHED'}


class VIBEGROWTH_OT_freeze(bpy.types.Operator):
    bl_idname = "vibegrowth.freeze"
    bl_label = "Freeze Current Frame"
    bl_description = "Copy the current growth state into a new static object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.vibegrowth.enabled

    def execute(self, context):
        src = context.object
        ob = bpy.data.objects.new(f"{src.name}_f{context.scene.frame_current}", src.data.copy())
        ob.matrix_world = src.matrix_world.copy()
        for coll in src.users_collection:
            coll.objects.link(ob)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

class VIEW3D_PT_vibegrowth(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "VibeGrowth"
    bl_label = "Differential Growth"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        ob = context.object
        if ob is None or ob.type != 'MESH':
            layout.label(text="Select a mesh (seed)")
            return
        st = ob.vibegrowth
        if not st.enabled:
            layout.operator(VIBEGROWTH_OT_create.bl_idname, icon='OUTLINER_OB_MESH')
            return

        row = layout.row(align=True)
        row.operator(VIBEGROWTH_OT_reset.bl_idname, icon='FILE_REFRESH')
        row.operator(VIBEGROWTH_OT_freeze.bl_idname, icon='FREEZE')
        layout.label(text=f"Vertices: {len(ob.data.vertices)}")

        seed = st.seed_object

        def section(idn, title, props, closed=False):
            header, body = layout.panel(idn, default_closed=closed)
            header.label(text=title)
            if body:
                for p in props:
                    if p in ("mask_group", "weight_group") and seed is not None:
                        body.prop_search(st, p, seed, "vertex_groups")
                    else:
                        body.prop(st, p)
            return body

        section("vg_seed", "Seed & Time",
                ["seed_object", "random_seed", "start_frame", "steps_per_frame"])
        section("vg_growth", "Growth",
                ["growth_rate", "interior_growth", "mask_group", "weight_group", "weight_space"])
        section("vg_noise", "Noise",
                ["noise_influence", "noise_scale", "noise_speed", "noise_space", "jitter"])
        section("vg_falloff", "Falloff from Core",
                ["core_object", "core_radius", "growth_decay"])
        section("vg_repel", "Repulsion & Collision",
                ["repulsion_distance", "repulsion_strength", "repulsion_exponent", "collision_distance"])
        section("vg_remesh", "Remesh",
                ["split_length", "max_vertices"])
        section("vg_solver", "Solver",
                ["spring_stiffness", "spring_iterations", "smoothing", "planar", "use_cache"], closed=True)


# ---------------------------------------------------------------------------

_classes = (
    VibeGrowthSettings,
    VIBEGROWTH_OT_create,
    VIBEGROWTH_OT_reset,
    VIBEGROWTH_OT_freeze,
    VIEW3D_PT_vibegrowth,
)


def register():
    for c in _classes:
        bpy.utils.register_class(c)
    bpy.types.Object.vibegrowth = PointerProperty(type=VibeGrowthSettings)
    bpy.app.handlers.frame_change_post.append(_on_frame_change)
    bpy.app.handlers.load_pre.append(_on_load_pre)


def unregister():
    for h, fn in ((bpy.app.handlers.frame_change_post, _on_frame_change),
                  (bpy.app.handlers.load_pre, _on_load_pre)):
        if fn in h:
            h.remove(fn)
    _on_load_pre()
    del bpy.types.Object.vibegrowth
    for c in reversed(_classes):
        bpy.utils.unregister_class(c)
