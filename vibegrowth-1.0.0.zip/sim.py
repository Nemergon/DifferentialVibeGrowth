"""Differential growth solver (no UI / bpy.types dependencies).

Model
-----
Every edge stores a rest length.  Growth increases the rest length of edges,
springs pull edges toward their rest length, repulsion keeps non-neighbouring
vertices apart, and edges that get longer than the split length are bisected
and the surrounding faces re-triangulated.  Only boundary / wire edges grow
by default, so an open disc ruffles along its rim and a wire curve meanders.
"""

import math
import random

import bmesh
import numpy as np
from mathutils import Vector, geometry, interpolate, kdtree, noise
from mathutils.bvhtree import BVHTree

# Attribute names (also written to the output mesh, usable in Geometry Nodes).
REST_LEN = "vg_rest_len"   # EDGE  float
REST_CO = "vg_rest_co"     # POINT vector, position in seed space
MASK = "vg_mask"           # POINT float, static initial growth mask
WEIGHT = "vg_weight"       # POINT float, dynamic weight (re-read every frame)
GROWTH = "vg_growth"       # POINT float, final growth factor of last step
AGE = "vg_age"             # POINT float, frame the vertex was born


class PointSampler:
    """Samples a per-vertex scalar of a source mesh at arbitrary points."""

    def __init__(self, cos, weights, tris, edges):
        self.cos = [Vector(c) for c in cos]
        self.w = list(weights)
        self.tris = tris
        self.bvh = BVHTree.FromPolygons(self.cos, tris) if tris else None
        self.kd = kdtree.KDTree(len(self.cos))
        for i, c in enumerate(self.cos):
            self.kd.insert(c, i)
        self.kd.balance()
        self.adj = [[] for _ in self.cos]
        for a, b in edges:
            self.adj[a].append(b)
            self.adj[b].append(a)

    def __call__(self, p):
        p = Vector(p)
        w = self.w
        if self.bvh is not None:
            loc, _nor, idx, _dist = self.bvh.find_nearest(p)
            if loc is not None:
                a, b, c = self.tris[idx]
                f = interpolate.poly_3d_calc([self.cos[a], self.cos[b], self.cos[c]], loc)
                return f[0] * w[a] + f[1] * w[b] + f[2] * w[c]
        if not self.cos:
            return 1.0
        _co, i, d = self.kd.find(p)
        best_d, best_w = d, w[i]
        for j in self.adj[i]:
            _pt, fac = geometry.intersect_point_line(p, self.cos[i], self.cos[j])
            fac = min(max(fac, 0.0), 1.0)
            dd = (p - self.cos[i].lerp(self.cos[j], fac)).length
            if dd < best_d:
                best_d, best_w = dd, w[i] * (1.0 - fac) + w[j] * fac
        return best_w


class GrowthSim:
    """Holds the growing BMesh and advances it frame by frame."""

    def __init__(self, bm, frame, seed, centroid, plane_normal):
        self.bm = bm
        self.frame = frame
        self.seed = seed
        self.centroid = np.array(centroid, dtype=float)
        self.plane_normal = np.array(plane_normal, dtype=float)
        rng = random.Random(seed)
        self.noise_offset = Vector([rng.uniform(-500.0, 500.0) for _ in range(3)])
        self._bind_layers()

    # ------------------------------------------------------------------ setup

    def _bind_layers(self):
        vl, el = self.bm.verts.layers, self.bm.edges.layers
        self.l_rest = el.float.get(REST_LEN) or el.float.new(REST_LEN)
        self.l_co = vl.float_vector.get(REST_CO) or vl.float_vector.new(REST_CO)
        self.l_mask = vl.float.get(MASK) or vl.float.new(MASK)
        self.l_weight = vl.float.get(WEIGHT) or vl.float.new(WEIGHT)
        self.l_growth = vl.float.get(GROWTH) or vl.float.new(GROWTH)
        self.l_age = vl.float.get(AGE) or vl.float.new(AGE)

    @classmethod
    def from_geometry(cls, cos, edges, faces, mask, frame, seed, split_length, max_vertices):
        P = np.array(cos, dtype=float).reshape(-1, 3)
        centroid = P.mean(axis=0) if len(P) else np.zeros(3)
        normal = np.array((0.0, 0.0, 1.0))
        if len(P) >= 3:
            _u, _s, vt = np.linalg.svd(P - centroid, full_matrices=False)
            normal = vt[-1] if vt.shape[0] == 3 else normal

        # Layers must exist before elements are created: adding a layer
        # afterwards invalidates existing Python element references.
        bm = bmesh.new()
        sim = cls(bm, frame, seed, centroid, normal)
        verts = [bm.verts.new(c) for c in cos]
        bm.verts.ensure_lookup_table()
        for f in faces:
            try:
                bm.faces.new([verts[i] for i in f])
            except ValueError:
                pass
        for a, b in edges:
            if a != b and bm.edges.get((verts[a], verts[b])) is None:
                bm.edges.new((verts[a], verts[b]))

        for v, m in zip(verts, mask):
            v[sim.l_co] = v.co
            v[sim.l_mask] = m
            v[sim.l_weight] = 1.0
            v[sim.l_age] = frame

        loose = [v for v in bm.verts if not v.link_edges]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context='VERTS')
        ngons = [f for f in bm.faces if len(f.verts) > 3]
        if ngons:
            bmesh.ops.triangulate(bm, faces=ngons, quad_method='BEAUTY', ngon_method='BEAUTY')
        for f in bm.faces:
            f.smooth = True
        for e in bm.edges:
            e[sim.l_rest] = e.calc_length()

        # Initial remesh so the seed already respects the split length.
        for _ in range(32):
            if not sim.split(split_length, max_vertices, frame):
                break
        return sim

    def copy(self):
        return GrowthSim(self.bm.copy(), self.frame, self.seed, self.centroid, self.plane_normal)

    def free(self):
        if self.bm is not None:
            self.bm.free()
            self.bm = None

    def write(self, mesh):
        self.bm.to_mesh(mesh)
        mesh.update()

    # --------------------------------------------------------------- per frame

    def advance(self, s, frame, weight_fn=None, weight_space='REST', to_seed=None, core=None):
        """Simulate one frame.  `weight_fn(point_in_seed_space) -> float`."""
        verts = self.bm.verts
        if weight_fn is None:
            for v in verts:
                v[self.l_weight] = 1.0
        elif weight_space == 'REST':
            for v in verts:
                v[self.l_weight] = weight_fn(v[self.l_co])
        else:
            for v in verts:
                p = to_seed @ v.co if to_seed is not None else v.co
                v[self.l_weight] = weight_fn(p)

        core = self.centroid if core is None else np.array(core, dtype=float)
        steps = max(1, int(s.steps_per_frame))
        for k in range(steps):
            t = (frame - 1) + (k + 1) / steps
            self._step(s, t, core, 1.0 / steps)
            self.split(s.split_length, s.max_vertices, frame)
        self.frame = frame

    def _step(self, s, t, core, dt):
        bm = self.bm
        verts, edges = bm.verts, bm.edges
        verts.index_update()
        n, m = len(verts), len(edges)
        if n == 0 or m == 0:
            return

        P = np.array([v.co[:] for v in verts], dtype=float)
        E = np.array([(e.verts[0].index, e.verts[1].index) for e in edges], dtype=np.int64)
        E0, E1 = E[:, 0], E[:, 1]
        R = np.array([e[self.l_rest] for e in edges], dtype=float)
        e_bound = np.array([e.is_boundary or e.is_wire for e in edges], dtype=bool)
        v_bound = np.zeros(n, dtype=bool)
        v_bound[E[e_bound].ravel()] = True

        # ---- growth factor per vertex
        g = np.array([v[self.l_mask] * v[self.l_weight] for v in verts], dtype=float)
        if s.noise_influence > 0.0:
            if s.noise_space == 'REST':
                pts = [v[self.l_co] for v in verts]
            else:
                pts = [Vector(p) for p in P.tolist()]
            drift = Vector((1.0, 0.618, 0.382)) * (t * s.noise_speed)
            off = self.noise_offset + drift
            sc = s.noise_scale
            nz = np.array([noise.noise(p * sc + off) for p in pts], dtype=float)
            g *= np.clip(1.0 + s.noise_influence * nz, 0.0, None)
        if s.growth_decay > 0.0:
            d = np.linalg.norm(P - core, axis=1)
            g *= np.exp(-s.growth_decay * np.maximum(0.0, d - s.core_radius))
        g *= np.where(v_bound, 1.0, s.interior_growth)

        # ---- grow rest lengths (frozen once the vertex budget is used up)
        if n < s.max_vertices:
            gE = 0.5 * (g[E0] + g[E1])
            R *= 1.0 + s.growth_rate * gE * dt

        # ---- edge springs (Jacobi position-based constraints)
        inv_cnt = 1.0 / np.maximum(np.bincount(E0, minlength=n) + np.bincount(E1, minlength=n), 1)
        for _ in range(max(1, int(s.spring_iterations))):
            D = P[E1] - P[E0]
            L = np.maximum(np.linalg.norm(D, axis=1), 1e-12)
            delta = D * ((1.0 - R / L) * 0.5 * s.spring_stiffness)[:, None]
            P += _scatter(n, E0, delta, E1, -delta) * inv_cnt[:, None]

        # ---- repulsion (exponential) + hard collision
        Rr, Rc = s.repulsion_distance, s.collision_distance
        Rq = max(Rr, Rc)
        if Rq > 0.0 and (s.repulsion_strength > 0.0 or Rc > 0.0):
            Pl = P.tolist()
            kd = kdtree.KDTree(n)
            for i, p in enumerate(Pl):
                kd.insert(p, i)
            kd.balance()
            I, J = [], []
            for i, p in enumerate(Pl):
                for _co, j, _d in kd.find_range(p, Rq):
                    if j > i:
                        I.append(i)
                        J.append(j)
            if I:
                I, J = np.array(I, dtype=np.int64), np.array(J, dtype=np.int64)
                keep = ~np.isin(I * n + J, _ring2_keys(n, E0, E1))
                I, J = I[keep], J[keep]
            if len(I):
                D = P[I] - P[J]
                d = np.linalg.norm(D, axis=1)
                tiny = d < 1e-9
                if tiny.any():
                    rnd = np.random.default_rng(len(I)).normal(size=(int(tiny.sum()), 3))
                    D[tiny] = rnd
                    d[tiny] = np.linalg.norm(rnd, axis=1)
                dirs = D / d[:, None]
                mag = np.zeros(len(d))
                if s.repulsion_strength > 0.0 and Rr > 0.0:
                    x = np.clip(d / Rr, 0.0, 1.0)
                    k = s.repulsion_exponent
                    if k > 1e-4:
                        f = (np.exp(k * (1.0 - x)) - 1.0) / (math.exp(k) - 1.0)
                    else:
                        f = 1.0 - x
                    mag += 0.5 * s.repulsion_strength * Rr * f
                if Rc > 0.0:
                    mag += 0.5 * np.maximum(Rc - d, 0.0)
                disp = dirs * mag[:, None]
                acc = _scatter(n, I, disp, J, -disp)
                lim = 0.5 * Rq
                norm = np.linalg.norm(acc, axis=1)
                over = norm > lim
                acc[over] *= (lim / norm[over])[:, None]
                P += acc

        # ---- smoothing (rim verts smooth along the rim only)
        if s.smoothing > 0.0:
            def nb_avg(sel):
                a, b = E0[sel], E1[sel]
                sums = _scatter(n, a, P[b], b, P[a])
                cnt = np.bincount(a, minlength=n) + np.bincount(b, minlength=n)
                return sums, cnt
            s_all, c_all = nb_avg(slice(None))
            s_b, c_b = nb_avg(e_bound)
            use_b = v_bound
            cnt = np.where(use_b, c_b, c_all)
            sums = np.where(use_b[:, None], s_b, s_all)
            ok = cnt >= 2
            avg = sums[ok] / cnt[ok][:, None]
            P[ok] += s.smoothing * (avg - P[ok])

        # ---- jitter (breaks symmetry, only where things grow)
        if s.jitter > 0.0:
            rng = np.random.default_rng((self.seed * 7919 + int(round(t * 1000))) & 0xFFFFFFFF)
            amp = s.jitter * s.split_length * 0.1 * np.minimum(g, 2.0)
            P += rng.normal(size=P.shape) * amp[:, None]

        if s.planar:
            nrm = self.plane_normal
            P -= ((P - self.centroid) @ nrm)[:, None] * nrm

        P = np.nan_to_num(P)
        for v, co, gg in zip(verts, P.tolist(), g.tolist()):
            v.co = co
            v[self.l_growth] = gg
        for e, r in zip(edges, R.tolist()):
            e[self.l_rest] = r

    # ---------------------------------------------------------------- remesh

    def split(self, split_length, max_vertices, frame):
        """Bisect every edge whose grown (rest) length exceeds split_length,
        or that is stretched beyond twice that, then triangulate."""
        if split_length <= 0.0:
            return 0
        bm = self.bm
        budget = int(max_vertices) - len(bm.verts)
        if budget <= 0:
            return 0
        lr = self.l_rest
        cands = [(max(e[lr], 0.5 * e.calc_length()), e) for e in bm.edges]
        cands = [c for c in cands if c[0] > split_length]
        if not cands:
            return 0
        cands.sort(key=lambda c: -c[0])

        lr, lco, lm, lw, lg = self.l_rest, self.l_co, self.l_mask, self.l_weight, self.l_growth
        touched = set()
        count = 0
        for _length, e in cands[:budget]:
            if not e.is_valid:
                continue
            a, b = e.verts
            r = e[lr]
            rest_co = (a[lco] + b[lco]) * 0.5
            mk = 0.5 * (a[lm] + b[lm])
            w = 0.5 * (a[lw] + b[lw])
            gr = 0.5 * (a[lg] + b[lg])
            ne, nv = bmesh.utils.edge_split(e, a, 0.5)
            e[lr] = ne[lr] = r * 0.5
            nv[lco] = rest_co
            nv[lm] = mk
            nv[lw] = w
            nv[lg] = gr
            nv[self.l_age] = frame
            touched.update(nv.link_faces)
            count += 1

        tri = [f for f in touched if f.is_valid and len(f.verts) > 3]
        if tri:
            res = bmesh.ops.triangulate(bm, faces=tri, quad_method='BEAUTY', ngon_method='BEAUTY')
            for e in res["edges"]:
                e[lr] = e.calc_length()
        return count


def _ring2_keys(n, E0, E1):
    """Pair keys (min*n+max) of all vertex pairs within 2 edges of each other."""
    src = np.concatenate((E0, E1))
    dst = np.concatenate((E1, E0))
    order = np.argsort(src, kind="stable")
    src, dst = src[order], dst[order]
    deg = np.bincount(src, minlength=n)
    starts = np.concatenate(([0], np.cumsum(deg)[:-1]))
    rep = deg[src]
    first = np.repeat(np.arange(len(src)), rep)
    within = np.arange(rep.sum()) - np.repeat(np.cumsum(rep) - rep, rep)
    a = dst[first]
    b = dst[starts[src[first]] + within]
    two = np.minimum(a, b) * n + np.maximum(a, b)
    one = np.minimum(E0, E1) * n + np.maximum(E0, E1)
    return np.concatenate((one, two))


def _scatter(n, ia, va, ib, vb):
    """Sum vectors va into rows ia and vb into rows ib of an (n, 3) array."""
    out = np.empty((n, 3))
    for k in range(3):
        out[:, k] = np.bincount(ia, va[:, k], minlength=n) + np.bincount(ib, vb[:, k], minlength=n)
    return out
